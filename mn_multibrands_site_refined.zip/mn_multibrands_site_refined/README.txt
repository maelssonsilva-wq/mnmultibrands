MN Multibrands - Versão refinada (preto & branco)
Instruções:
- Substitua imagens em /images por fotos de produto reais (prod1.jpg, prod2.jpg, prod3.jpg, logo.png)
- Abra index.html localmente ou faça deploy em GitHub Pages / Netlify
- Caso queira alterar o número de WhatsApp, edite script.js (variável phone)
